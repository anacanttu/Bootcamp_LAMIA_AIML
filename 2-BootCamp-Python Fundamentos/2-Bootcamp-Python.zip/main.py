#!python3

# print('Bem vindo!')
# import pacote.sub.arquivo
# import tipos.variaveis
#from tipos import variaveis
#import tipos.lista 
#import tipos.tuplas
#import tipos.conjuntos
#import tipos.dicionario

#import operadores.unitarios
#import operadores.aritmeticos
#import operadores.relacionais
#import operadores.atribuicao
#import operadores.logicos
#import operadores.ternario

#import controle.if_1 
#import controle.if_2
#import controle.for_1
#import controle.while_1
#import controle.outros_exemplos 

#from funcoes import basico
#basico.saudacao()
#basico.saudacao('Maria')
#basico.saudacao('Joao, 33')
#basico.saudacao(idade = 89)
#a = basico.soma_e_multi(x=10, a=2, b=3)
#b = basico.soma_e_multi(x=20, a=3, b=7)
#resultado = a + b
#print(f'Resultado: {resultado}')

#from funcoes import args
#s = args.soma(1, 2, 3, 7, 8, 9, 10)
#print(s)
#resultado = args.resultado_final(nome = 'Pedro', nota = 6.3)
#print(resultado)

#from funcoes import funcional
# import funcoes.map_reduce
# import funcoes.lambdas
# import funcoes.comprehension

# import oo.produto
# import oo.heranca
# import oo.membros
