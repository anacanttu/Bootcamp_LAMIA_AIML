x = 7 
y = 5

print(x>y)
print(x>=y)
print(x<y)
print(x<=y)
print(x==y)
print(x!=y)

print('5' != 5)