x = 10
y = 3

# +3 prefix
# ++2 prefix
# -3 postfix
# --2 postfix
# x + y infix

print (x + y)
print (x - y)
print (x * y)
print (x / y)
print (x % y)
print (x ** y)
print (x // y)

par = 34
impar = 33

print (par % 2 == 0)
print (impar % 2 == 1)