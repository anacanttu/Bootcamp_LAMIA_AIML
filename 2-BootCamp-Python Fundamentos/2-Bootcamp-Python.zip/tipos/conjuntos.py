print({1,2,3})
print(type({1,2,3}))
print({1,2,3, 3, 3, 3, 3})

conj = {1,2,3, 3, 3, 3, 3}
#print(conj[1])
print(len(conj))
