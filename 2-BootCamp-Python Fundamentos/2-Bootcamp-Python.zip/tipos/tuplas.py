nomes = ('Ana', 'Bia', 'Gui', 'Ana')

print('Bia' in nomes)

print(nomes[0])
print(nomes[1:3])
print(nomes[1:-1])
print(nomes[2:])
print(nomes[:-2])
print(len(nomes))
print(type(nomes))
print(nomes)